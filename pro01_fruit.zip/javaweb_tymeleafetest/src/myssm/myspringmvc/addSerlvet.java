package myssm.myspringmvc;

import myssm.dao.FruitDAO;
import myssm.dao.Impl.FruitDaoImpl;
import pojo.Fruit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class addSerlvet extends ViewBaseServlet{
    FruitDAO fruitDAO = new FruitDaoImpl();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String fname = req.getParameter("fname");
        String strprice = req.getParameter("price");
        int price = Integer.parseInt(strprice);
        String strfcount = req.getParameter("fcount");
        int fcount = Integer.parseInt(strfcount);
        String remark = req.getParameter("remark");

        fruitDAO.addFruit(new Fruit(null,fname,price,fcount,remark));
        System.out.println("hello");
        resp.sendRedirect("indexservlet");
    }
}
