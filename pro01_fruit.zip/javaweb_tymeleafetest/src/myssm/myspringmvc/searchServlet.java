package myssm.myspringmvc;

import myssm.dao.FruitDAO;
import myssm.dao.Impl.FruitDaoImpl;
import pojo.Fruit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class searchServlet extends ViewBaseServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String keyword = req.getParameter("keyword");
        if(keyword!=""){
            FruitDAO fruitDAO = new FruitDaoImpl();
            List<Fruit> searchList = fruitDAO.getFruitByKeyword(keyword);
            HttpSession session = req.getSession();
            session.setAttribute("fruitList",searchList);
            super.processTemplate("index",req,resp);
        }else{
            resp.sendRedirect("indexservlet");
        }
    }
}
