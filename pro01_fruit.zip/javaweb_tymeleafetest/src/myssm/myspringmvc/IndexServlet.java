package myssm.myspringmvc;

import myssm.dao.FruitDAO;
import myssm.dao.Impl.FruitDaoImpl;
import pojo.Fruit;
import utils.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class IndexServlet extends ViewBaseServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //默认页码数是第一页
        Integer pageNo = 1;
        //获取当前页码数
        String pageNostr = req.getParameter("pageNo");
        if(StringUtils.isNotEmpty(pageNostr)){
            pageNo = Integer.parseInt(pageNostr);
        }
        //获取总页码数
        FruitDAO fruitDAO = new FruitDaoImpl();
        int numNototal = fruitDAO.getFruitNum();
        //将当前页码数保存到session作用区域
        HttpSession session = req.getSession();
        session.setAttribute("pageNo",pageNo);
        //将总页码计算并保存到session中
        int pagetotal = numNototal/5+1;
        session.setAttribute("pagetotal",pagetotal);

        FruitDaoImpl fruitDao = new FruitDaoImpl();
        List<Fruit> list = fruitDao.getFruitList(pageNo);
        session.setAttribute("fruitList",list);
        super.processTemplate("index",req,resp);
    }
}
