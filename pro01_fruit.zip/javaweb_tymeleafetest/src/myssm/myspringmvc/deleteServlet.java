package myssm.myspringmvc;

import myssm.dao.FruitDAO;
import myssm.dao.Impl.FruitDaoImpl;
import pojo.Fruit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class deleteServlet extends ViewBaseServlet{
    FruitDAO fruitDAO = new FruitDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取属性
        String strfid = req.getParameter("fid");
        int fid = Integer.parseInt(strfid);
        //利用fruitdao操作数据库
        fruitDAO.delFruit(fruitDAO.getFruitByFid(fid).getFname());
        //请求重定向
        resp.sendRedirect("indexservlet");
    }
}
