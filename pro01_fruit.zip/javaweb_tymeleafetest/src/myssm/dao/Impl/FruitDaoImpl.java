package myssm.dao.Impl;

import myssm.dao.BaseDao;
import myssm.dao.FruitDAO;
import pojo.Fruit;

import java.util.List;

public class FruitDaoImpl extends BaseDao implements FruitDAO {

    @Override
    public List<Fruit> getFruitList(Integer pageNo) {
        String sql = "select * from t_fruit limit ? , 5";
        return queryForList(Fruit.class,sql,(pageNo-1)*5);
    }

    @Override
    public int addFruit(Fruit fruit) {
        String sql = "insert into t_fruit values(?,?,?,?,?)";
        return update(sql,fruit.getFid(),fruit.getFname(),fruit.getPrice(),fruit.getFcount(),fruit.getRemark());
    }

    @Override
    public int updateFruit(Fruit fruit) {
        String sql = "update t_fruit set fname=?,price=?,fcount=?,remark=? where fid=?";
        return update(sql,fruit.getFname(),fruit.getPrice(),fruit.getFcount(),fruit.getRemark(),fruit.getFid());
    }

    @Override
    public Fruit getFruitByFname(String fname) {
        String sql = "select * from t_fruit where fname=?";
        return queryForOne(Fruit.class,sql,fname);
    }

    @Override
    public Fruit getFruitByFid(Integer fid) {
        String sql = "select * from t_fruit where fid=?";
        return queryForOne(Fruit.class,sql,fid);
    }

    @Override
    public int delFruit(String fname) {
        String sql = "delete from t_fruit where fname=?";
        return update(sql,fname);
    }

    @Override
    public int getFruitNum() {
        String sql = "select count(*) from t_fruit";
        Integer num = ((Long) queryForSingleValue(sql)).intValue();
        return num;
    }

    @Override
    public List<Fruit> getFruitByKeyword(String keyword) {
        String sql = "select * from t_fruit where fname like ?";
        return queryForList(Fruit.class,sql,"%"+keyword+"%");
    }
}
