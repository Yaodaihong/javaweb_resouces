package myssm.dao;

import pojo.Fruit;

import java.util.List;

public interface FruitDAO {
    //获取指定页码的库存信息,每一页显示五行
    List<Fruit> getFruitList(Integer pageNo);

    //新增库存
    int addFruit(Fruit fruit);

    //修改库存
    int updateFruit(Fruit fruit);

    //根据名称查询特定库存
    Fruit getFruitByFname(String fname);

    //根据id查询特定库存
    Fruit getFruitByFid(Integer fid);

    //删除特定库存记录
    int delFruit(String fname);

    //查询总记录条数的方法
     int getFruitNum();

     //利用关键字查询数据
    List<Fruit> getFruitByKeyword(String keyword);
}
