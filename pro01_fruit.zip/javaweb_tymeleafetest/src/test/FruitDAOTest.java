package test;

import myssm.dao.Impl.FruitDaoImpl;
import org.junit.Test;
import pojo.Fruit;

import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.*;

public class FruitDAOTest {

    private FruitDaoImpl fruitDao = new FruitDaoImpl();

    @Test
    public void getFruitList() {
        List<Fruit> list = fruitDao.getFruitList(1);
        Iterator iterator = list.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    @Test
    public void addFruit() {
        Fruit fruit = new Fruit(9,"梨子",6,20,"孔融让梨");
        fruitDao.addFruit(fruit);
    }

    @Test
    public void updateFruit() {
        Fruit fruit = new Fruit(8,"梨子",6,20,"孔融不让梨");
        fruitDao.updateFruit(fruit);
    }

    @Test
    public void getFruitByFname() {
        Fruit fruit = fruitDao.getFruitByFname("西红柿");
        System.out.println(fruit);
    }

    @Test
    public void delFruit() {
        fruitDao.delFruit("梨子");
    }

    @Test
    public void getFruitByFid() {
       Fruit fruit = fruitDao.getFruitByFid(1);
       System.out.println(fruit);
    }

    @Test
    public void getFruitNum() {
        System.out.println(fruitDao.getFruitNum());
    }

    @Test
    public void getFruitByKeyword() {
        List fruit = fruitDao.getFruitByKeyword("梨");
        System.out.println(fruit);
    }

}