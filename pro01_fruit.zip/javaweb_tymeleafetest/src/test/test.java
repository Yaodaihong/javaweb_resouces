package test;

import org.junit.Test;
import utils.JdbcUtils;

import java.sql.Connection;

public class test {
    @Test
    public void test1(){
        Connection conn = JdbcUtils.getConnection();
        System.out.println(conn);
    }
}
