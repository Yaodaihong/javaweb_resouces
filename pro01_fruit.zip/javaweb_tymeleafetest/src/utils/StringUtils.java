package utils;

public class StringUtils {
    public static Boolean isEmpty(String str){
        return str==null ||"".equals(str);
    }

    public static Boolean isNotEmpty(String str){
        return !(str==null ||"".equals(str));
    }
}
